package fr.falkoyt;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CommanduhcKit implements CommandExecutor {


	private static final String player = null;

	@Override
	public boolean onCommand(CommandSender sender, Command cdm, String msg, String[] args) {
	
		if(sender instanceof Player){

			if(args.length == 0) {
				sender.sendMessage(ChatColor.GOLD+">>UHC �4 Vous avez re�u votre KIT avec succ�s !!!");
				new WorldSounds(((Player) sender).getLocation()).playSound(Sound.ANVIL_USE);
				Kit.give(player);
		
			}
			return true;
		}
		return false;
  }
}
	



