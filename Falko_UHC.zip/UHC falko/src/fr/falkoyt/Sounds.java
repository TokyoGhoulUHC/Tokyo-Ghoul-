package fr.falkoyt;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class Sounds implements Listener{
	
	private Player player;
	
	public Sounds(Player p){
		player = p;
	}
	
	public Sounds() {
		// TODO Auto-generated constructor stub
	}

	public void playSound(Sound s){
		player.playSound(player.getLocation(), s, 8, 8);
	}

}
