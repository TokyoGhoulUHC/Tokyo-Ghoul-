package fr.falkoyt;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

public class Commanduhcrevive implements CommandExecutor {

	private static final PlayerInteractEvent Player = null;

	@Override
	public boolean onCommand(CommandSender sender, Command cdm, String msg, String[] args) {
	
		if(sender instanceof Player){

			if(args.length ==  1) {
				Bukkit.broadcastMessage(ChatColor.GOLD+">>UHC §4 Un Joueur §3 A été REVIVE");
				new WorldSounds(((Player) sender).getLocation()).playSound(Sound.AMBIENCE_THUNDER);
				UHCrevive.revive(Player);
		
			}
			return true;
		}
		return false;
  }


}
