package fr.falkoyt;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
public class CommanduhcStart implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cdm, String msg, String[] args) {
		if(sender instanceof Player){
			if(args.length == 0) {
				Bukkit.broadcastMessage(ChatColor.AQUA+">>UHC §4 Vous avez été téléporté avec succès !!!");
				// on appelle la fonction start de la cmd
				UHCGame.start();
			}
			return true;
		}
		return false;
  }
	
}

