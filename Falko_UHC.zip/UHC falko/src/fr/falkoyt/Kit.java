package fr.falkoyt;

import java.util.ArrayList;
import java.util.Collection;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public enum Kit {
	
  KIT1("1"),  KIT2("2"),  KIT3("3"),  KIT4("4");
  
  private String s;
  
  private Kit(String s){
    this.s = s;
  }
  
  @SuppressWarnings({ "unchecked", "rawtypes", "deprecation", "unused" })
public void give(Player player)
  {
    ArrayList<ItemStack> kit = new ArrayList();
    ItemMeta efm;
    if (this.s.equals("1"))
    {
      player.sendMessage("Bonne Nouvelle tu et une Ghoul Borgne tu obptiendras ton kit en tappant /kit !!!!");
      kit.addAll((Collection<? extends ItemStack>) new PotionEffect(PotionEffectType.FAST_DIGGING, 60000, 1, true));
      kit.addAll((Collection<? extends ItemStack>) new PotionEffect(PotionEffectType.SPEED, 60000, 1, true));
    }
    else if (this.s.equals("2"))
    {
      player.sendMessage("Attention tu et Une Ghoul, obtient ton kit en tappant /kit !!!");
      ItemStack lf = new ItemStack(Material.ENCHANTED_BOOK, 1, (short)1);
      EnchantmentStorageMeta lfm = (EnchantmentStorageMeta)lf.getItemMeta();
      lfm.addStoredEnchant(Enchantment.DAMAGE_ALL, 3, true);
      lf.setItemMeta(lfm);
      kit.add(lf);
      kit.addAll((Collection<? extends ItemStack>) new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 60000, 1, true));
    }
    else if (this.s.equals("3"))
    {
      player.sendMessage("Bravo tu est devenue POLICIER. en fesant /kit tu obtient ton kit !! ");
      ItemStack lf = new ItemStack(Material.ENCHANTED_BOOK, 1);
      EnchantmentStorageMeta lfm = (EnchantmentStorageMeta)lf.getItemMeta();
      lfm.addStoredEnchant(Enchantment.PROTECTION_FALL, 3, true);
      kit.add(lf);
      kit.addAll((Collection<? extends ItemStack>) new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 60000, 1, true));
    }
    else
    {
      kit.add(new ItemStack(Material.getMaterial(373), 1, (short)16388));
      kit.add(new ItemStack(Material.getMaterial(373), 1, (short)16394));
      kit.add(new ItemStack(Material.getMaterial(373), 1, (short)16392));
      kit.add(new ItemStack(Material.getMaterial(373), 1, (short)16396));
    }
    for (ItemStack item : kit) {
      player.getWorld().dropItem(player.getLocation(), item);
    }
  }

public static void give(String player) {
	// TODO Auto-generated method stub
	
}


}
