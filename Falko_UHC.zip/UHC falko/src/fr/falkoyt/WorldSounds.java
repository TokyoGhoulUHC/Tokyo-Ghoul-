package fr.falkoyt;

import org.bukkit.Location;
import org.bukkit.Sound;

public class WorldSounds {

	public WorldSounds(Location location) {
		// TODO Auto-generated constructor stub
	}

	public void playSound(Sound WitherSpawn) {
		// TODO Auto-generated method stub
		
	}

}
