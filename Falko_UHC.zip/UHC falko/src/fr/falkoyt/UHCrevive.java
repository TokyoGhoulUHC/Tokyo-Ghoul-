package fr.falkoyt;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;

public class UHCrevive {

	public static void revive(PlayerInteractEvent e){
	
	Player p = e.getPlayer();
	if(UHCState.GAME != null) {
		
		p.getPlayer().setGameMode(GameMode.SURVIVAL);
		p.sendMessage("Vous avez �t� Revive bonne partie.");
		p.getPlayer().updateInventory();
		p.getPlayer().setMaxHealth(20);
		((Team) e.getPlayer()).getTeam();
	}
	
	}

}
