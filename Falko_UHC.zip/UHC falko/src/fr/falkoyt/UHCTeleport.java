package fr.falkoyt;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.Listener;

public class UHCTeleport implements Listener {

	/*public static void tpRandom(Team t) {
		
		Random r = new Random();
		
		//ON CREER LES POINTS ALEATOIRES EN X EN Y ET EN Z ET ON MET LE MONDE
		World world = Bukkit.getWorld("world");
		int x = r.nextInt(1000);
		int z = r.nextInt(1000);
		int y = world.getHighestBlockYAt(x, z);
		
		//ON CREER LA LOCATION EN FONCTION DES POINTS PRECEDENTS
		Location randomLoc = new Location(world, x,y,z);
		
		for(String name : t.getTeam().getEntries()) {
			Player p = Bukkit.getPlayer(name);
			if(p != null) {
				p.teleport(randomLoc);
			}
		}
	}*/
	
	public static List<Location> getCircle(Location center, double radius, int amount) {
	    List<Location> locations = new ArrayList<>();
	    World world = center.getWorld();
	    double increment = (2 * Math.PI) / amount;
	    for(int i = 0; i < amount; i++) {
	        double angle = i * increment;
	        double x = center.getX() + (radius * Math.cos(angle));
	        double z = center.getZ() + (radius * Math.sin(angle));
	        int y = world.getHighestBlockYAt((int)x, (int)z);
	        locations.add(new Location(world, x, y, z));
	    }
	    return locations;
	}
}
